// import logo from './logo.svg';
// import './App.css';

// import AdminPanel from "./Admin/AdminPanel";
import Home from "./Components/Home";

function App() {
  return (
    <div className="App">
    <Home/>
    {/* <AdminPanel/> */}
    </div>    
  );
}

export default App;
